local Element = {}

-- soon
-- im lazy

function Element.New()
    
end


return Element